package com.example.android.architecture.blueprints.todoapp.statistics

import com.example.android.architecture.blueprints.todoapp.data.Task
import org.hamcrest.CoreMatchers.`is`
import org.junit.Assert.*
import org.junit.Test

class StatisticsUtilsTest{

    /*
    If there is 0 completed task and 1 active task,
    then there are 0% completed tasks, and 100% active tasks.
     */
    @Test
    fun getActiveAndCompletedStats_noCompleted_returnsZeroHundred(){
        // GIVEN a list of tasks with : 0 completed task(s), 1 active task(s).
        val tasks = listOf<Task>(
            Task("title","description",isCompleted = false)
        )

        // WHEN you call getActiveAndCompletedStats
        val result = getActiveAndCompletedStats(tasks)

        // THEN there are 0% completed tasks and 100% active tasks
        assertEquals(0f, result.completedTasksPercent)
        assertEquals(100f, result.activeTasksPercent)

        //Hamecrest Framework
        assertThat(result.completedTasksPercent, `is`(0f))
        assertThat(result.activeTasksPercent, `is`(100f))
    }

    /*
    If there are 2 completed tasks and 3 active tasks,
    then there are 40% completed tasks, and 60% active tasks.
     */
    @Test
    fun getActiveAndCompletedStats_both_returnsFortySixty(){
        // GIVEN a list of tasks with : 2 completed task(s), 3 active task(s).
        val tasks = listOf<Task>(
            Task("title","description",isCompleted = true),
            Task("title","description",isCompleted = true),
            Task("title","description",isCompleted = false),
            Task("title","description",isCompleted = false),
            Task("title","description",isCompleted = false)
        )

        // WHEN you call getActiveAndCompletedStats
        val result = getActiveAndCompletedStats(tasks)

        // THEN there are 40% completed tasks and 60% active tasks
        assertEquals(40f, result.completedTasksPercent)
        assertEquals(60f, result.activeTasksPercent)
        //Hamecrest Framework
        assertThat(result.completedTasksPercent, `is`(40f))
        assertThat(result.activeTasksPercent, `is`(60f))
    }

    /*
    If there are 1 completed tasks and 0 active tasks,
    then there are 100% completed tasks, and 0% active tasks.
     */
    @Test
    fun getActiveAndCompletedStats_noActive_returnsHundredZero(){
        // GIVEN a list of tasks with : 1 completed task(s), 0 active task(s).
        val tasks = listOf<Task>(
            Task("title","description",isCompleted = true)
        )

        // WHEN you call getActiveAndCompletedStats
        val result = getActiveAndCompletedStats(tasks)

        // THEN there are 100% completed tasks and 0% active tasks
        assertEquals(100f, result.completedTasksPercent)
        assertEquals(0f, result.activeTasksPercent)
        //Hamecrest Framework
        assertThat(result.completedTasksPercent, `is`(100f))
        assertThat(result.activeTasksPercent, `is`(0f))
    }

    /*
    If tasks is empty
    then there are 0% completed tasks, and 0% active tasks.
     */
    @Test
    fun getActiveAndCompletedStats_emptyTasks_returnsZeroZero(){
        // GIVEN an empty list of tasks with : 0 completed task(s), 0 active task(s).
        val tasks = emptyList<Task>()

        // WHEN you call getActiveAndCompletedStats
        val result = getActiveAndCompletedStats(emptyList())

        // THEN there are 0% completed tasks and 0% active tasks
        assertEquals(0f, result.completedTasksPercent)
        assertEquals(0f, result.activeTasksPercent)

        //Hamecrest Framework
        assertThat(result.completedTasksPercent, `is`(0f))
        assertThat(result.activeTasksPercent, `is`(0f))
    }

    /*
    If tasks is null
    then there are 0% completed tasks, and 0% active tasks.
     */
    @Test
    fun getActiveAndCompletedStats_nullTasks_returnsZeroZero(){
        // GIVEN there is no list of tasks, the reference is null.
        val tasks = null

        // WHEN you call getActiveAndCompletedStats
        val result = getActiveAndCompletedStats(tasks)

        // THEN there are 0% completed tasks and 0% active tasks
        assertEquals(0f, result.completedTasksPercent)
        assertEquals(0f, result.activeTasksPercent)
        //Hamecrest Framework
        assertThat(result.completedTasksPercent, `is`(0f))
        assertThat(result.activeTasksPercent, `is`(0f))
    }
}